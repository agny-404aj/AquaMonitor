
import React from 'react';
import { Screen } from '../types';

interface SidebarProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentScreen, onNavigate }) => {
  const navItems = [
    { id: Screen.HOME, icon: 'home', label: 'Home', hindi: 'मुख्य पृष्ठ' },
    { id: Screen.HISTORY, icon: 'history', label: 'Water History', hindi: 'पानी का इतिहास' },
    { id: Screen.MANUAL_ENTRY, icon: 'edit_note', label: 'Manual Entry', hindi: 'मैनुअल एंट्री' },
    { id: Screen.ALERTS, icon: 'notifications', label: 'Alerts', hindi: 'चेतावनियाँ' },
  ];

  return (
    <aside className="w-72 border-r border-earth/10 bg-white flex flex-col justify-between p-6 shrink-0 shadow-xl h-screen sticky top-0">
      <div className="flex flex-col gap-10">
        <div className="flex items-center gap-4 px-2">
          <div className="bg-primary p-2.5 rounded-2xl shadow-lg">
            <span className="material-symbols-outlined text-white !text-3xl">water_drop</span>
          </div>
          <div>
            <h1 className="text-xl font-extrabold leading-tight text-primary">Jal Sachet</h1>
            <p className="text-earth font-hindi text-lg font-bold">जल सचेत</p>
          </div>
        </div>
        
        <nav className="flex flex-col gap-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center gap-4 px-4 py-4 rounded-2xl transition-all text-left ${
                currentScreen === item.id 
                  ? 'bg-primary text-white shadow-md shadow-primary/20' 
                  : 'text-earth/70 hover:bg-earth/5'
              }`}
            >
              <span className="material-symbols-outlined !text-2xl">{item.icon}</span>
              <div className="flex flex-col">
                <span className="text-xs font-bold uppercase tracking-wider">{item.label}</span>
                <span className="text-lg font-hindi leading-none">{item.hindi}</span>
              </div>
            </button>
          ))}
        </nav>
      </div>

      <div className="border-t border-earth/10 pt-6">
        <div className="flex items-center gap-4 p-3 bg-earth/5 rounded-2xl">
          <div className="size-12 rounded-full border-2 border-white shadow-sm overflow-hidden bg-cover" style={{ backgroundImage: "url('https://picsum.photos/seed/villagehead/100/100')" }}></div>
          <div className="flex flex-col">
            <span className="text-sm font-bold">Panchayat Head</span>
            <span className="text-lg font-hindi leading-none">सरपंच</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
