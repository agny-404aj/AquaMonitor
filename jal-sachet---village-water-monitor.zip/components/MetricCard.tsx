
import React from 'react';
import { WaterMetric } from '../types';

interface MetricCardProps {
  metric: WaterMetric;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  const colorMap: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600',
    amber: 'bg-amber-50 text-amber-700',
    teal: 'bg-teal-50 text-teal-600',
    orange: 'bg-orange-50 text-orange-600',
    purple: 'bg-purple-50 text-purple-600',
  };

  const barColorMap: Record<string, string> = {
    blue: 'bg-blue-500',
    amber: 'bg-amber-500',
    teal: 'bg-teal-500',
    orange: 'bg-orange-500',
    purple: 'bg-purple-500',
  };

  const statusBgMap: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-700',
    amber: 'bg-amber-50 text-amber-700',
    teal: 'bg-teal-50 text-teal-700',
    orange: 'bg-orange-50 text-orange-700',
    purple: 'bg-purple-50 text-purple-700',
  };

  return (
    <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-earth/5 hover:shadow-xl transition-all group">
      <div className="flex justify-between items-start mb-6">
        <div className={`p-4 rounded-3xl group-hover:scale-110 transition-transform ${colorMap[metric.color] || 'bg-slate-50 text-slate-600'}`}>
          <span className="material-symbols-outlined icon-large">{metric.icon}</span>
        </div>
        <div className="text-right">
          <span className="text-sm font-bold text-slate-400 uppercase">{metric.label}</span>
          <h4 className={`text-2xl font-hindi font-bold ${(colorMap[metric.color] || 'text-slate-600').split(' ')[1]}`}>{metric.hindiLabel}</h4>
        </div>
      </div>
      <div className="mt-4">
        <p className="text-5xl font-black text-slate-800">{metric.value} <span className="text-xl text-slate-400">{metric.unit}</span></p>
        <div className="w-full h-4 bg-slate-100 rounded-full mt-6 overflow-hidden flex">
          <div className={`h-full ${barColorMap[metric.color] || 'bg-slate-500'}`} style={{ width: `${metric.percentage}%` }}></div>
        </div>
        <p className={`mt-4 text-center font-hindi font-bold py-2 rounded-lg italic ${statusBgMap[metric.color] || 'bg-slate-50 text-slate-700'}`}>
          {metric.hindiStatus} ({metric.status})
        </p>
      </div>
    </div>
  );
};

export default MetricCard;
