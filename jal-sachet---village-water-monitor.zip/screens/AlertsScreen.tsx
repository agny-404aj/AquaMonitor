
import React from 'react';
import { ALERTS } from '../constants';

const AlertsScreen: React.FC = () => {
  return (
    <div className="flex flex-col gap-10">
      {/* Critical Danger Alert */}
      <div className="bg-danger-red rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
        <div className="flex items-center justify-between px-8 py-5 bg-black/20">
          <div className="flex items-center gap-4">
            <span className="material-symbols-outlined text-white !text-4xl animate-pulse">emergency_home</span>
            <span className="text-white font-black text-3xl tracking-tight uppercase">Danger | खतरा</span>
          </div>
          <span className="text-white font-bold text-lg bg-white/20 px-6 py-2 rounded-full">Station: West Well (पश्चिमी कुआं)</span>
        </div>
        <div className="p-10 text-white">
          <div className="flex flex-col lg:flex-row gap-12 items-start">
            <div className="flex-1">
              <h1 className="text-5xl font-black mb-6 leading-tight">Water Level High! <br/><span className="text-white/80">पानी का स्तर बहुत ऊपर है!</span></h1>
              <p className="text-2xl opacity-90 mb-6 font-medium leading-relaxed">The water level has reached the danger mark. Please stay away from the reservoir and move to higher ground.</p>
              <p className="text-2xl opacity-90 mb-10 font-bold leading-relaxed">जल स्तर खतरे के निशान तक पहुँच गया है। कृपया जलाशय से दूर रहें और सुरक्षित स्थान पर जाएँ।</p>
              <div className="flex flex-wrap gap-6">
                <button className="flex-1 min-w-[250px] flex items-center justify-center gap-4 rounded-2xl h-20 bg-white text-danger-red hover:bg-slate-100 text-2xl font-black transition-all shadow-xl">
                  <span className="material-symbols-outlined !text-4xl">phone_in_talk</span>
                  CALL HELP (मदद लें)
                </button>
                <button className="flex-1 min-w-[250px] flex items-center justify-center gap-4 rounded-2xl h-20 bg-black/30 text-white hover:bg-black/40 border-2 border-white/30 text-2xl font-black transition-all">
                  <span className="material-symbols-outlined !text-4xl">record_voice_over</span>
                  NOTIFY PRADHAN
                </button>
              </div>
            </div>
            <div className="w-full lg:w-80 bg-white/10 backdrop-blur-md rounded-[2rem] p-8 border border-white/20 shadow-inner">
              <p className="text-xs font-black uppercase tracking-widest mb-6 opacity-70">Sensor Reading</p>
              <div className="mb-6">
                <p className="text-6xl font-black">5.2m</p>
                <p className="text-lg opacity-80 mt-1">Limit: 4.0m</p>
              </div>
              <div className="w-full bg-white/20 h-4 rounded-full overflow-hidden">
                <div className="bg-white h-full w-[95%]"></div>
              </div>
              <p className="mt-6 text-sm font-bold italic opacity-70">Updated 30 seconds ago</p>
            </div>
          </div>
        </div>
      </div>

      {/* Community Notifications */}
      <section>
        <h2 className="text-2xl font-black mb-8 flex items-center gap-4">
          <span className="material-symbols-outlined text-primary !text-4xl">campaign</span>
          Community Notifications | सामुदायिक सूचनाएं
        </h2>
        <div className="grid gap-6">
          {ALERTS.map((alert) => (
            <div key={alert.id} className="bg-white border border-slate-100 rounded-[2rem] p-8 flex gap-8 items-start hover:shadow-xl transition-all">
              <div className={`size-16 rounded-full flex items-center justify-center shrink-0 ${
                alert.type === 'warning' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
              }`}>
                <span className="material-symbols-outlined !text-3xl">{alert.type === 'warning' ? 'warning' : 'info'}</span>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-black text-2xl text-slate-800">{alert.title}</h3>
                    <h4 className={`text-xl font-hindi font-bold ${alert.type === 'warning' ? 'text-amber-700' : 'text-blue-700'}`}>{alert.hindiTitle}</h4>
                  </div>
                  <span className="text-sm font-bold text-slate-400 bg-slate-50 px-4 py-1 rounded-full">{alert.time}</span>
                </div>
                <p className="text-slate-600 text-lg mb-2">{alert.description}</p>
                <p className="text-slate-600 text-lg font-hindi font-medium">{alert.hindiDescription}</p>
              </div>
              <button className="px-8 py-3 bg-slate-50 hover:bg-slate-100 rounded-2xl text-sm font-black transition-colors self-center">
                Acknowledge
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Emergency Contacts */}
      <section>
        <h3 className="text-2xl font-black mb-8 flex items-center gap-4">
          <span className="material-symbols-outlined text-danger-red !text-4xl">contact_phone</span>
          Emergency Contacts | आपातकालीन संपर्क
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { label: 'Village Pradhan', icon: 'person', phone: '+91 98765 43210' },
            { label: 'Maintenance Desk', icon: 'plumbing', phone: '+91 98765 43211' },
            { label: 'Health Center', icon: 'health_and_safety', phone: '108 / 102' },
          ].map((contact, idx) => (
            <div key={idx} className="p-8 bg-white rounded-3xl border border-slate-100 flex items-center gap-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="size-16 rounded-2xl bg-slate-50 flex items-center justify-center text-primary shadow-inner">
                <span className="material-symbols-outlined !text-4xl">{contact.icon}</span>
              </div>
              <div>
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{contact.label}</p>
                <p className="font-black text-2xl text-slate-900 mt-1">{contact.phone}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Motivational Footer Note */}
      <div className="mt-6 p-12 bg-primary/5 rounded-[3rem] border-2 border-dashed border-primary/20 text-center">
        <span className="material-symbols-outlined !text-6xl text-primary mb-6">favorite</span>
        <h4 className="text-3xl font-black mb-4">We are here for you | हम आपके साथ हैं</h4>
        <p className="text-slate-600 text-xl max-w-2xl mx-auto leading-relaxed">
          This system is designed to keep our village safe. If you see anything unusual with the water supply, please report it immediately using the buttons above.
        </p>
      </div>
    </div>
  );
};

export default AlertsScreen;
