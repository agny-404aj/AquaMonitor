
import React from 'react';
import { HISTORY } from '../constants';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const WaterHistory: React.FC = () => {
  return (
    <div className="grid grid-cols-12 gap-8">
      {/* Sidebar Info */}
      <div className="col-span-12 lg:col-span-4 flex flex-col gap-6">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-100 shadow-sm flex flex-col gap-6">
          <h4 className="text-lg font-black text-slate-800 border-b pb-4 border-slate-50">Comparison | तुलना</h4>
          <div className="space-y-8">
            <div className="relative pl-12">
              <span className="material-symbols-outlined absolute left-0 top-1 text-4xl text-emerald-500">sentiment_very_satisfied</span>
              <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Today | आज</p>
              <p className="text-3xl font-black text-slate-900">Clean Water</p>
              <p className="text-emerald-600 font-bold">शुद्ध पानी</p>
            </div>
            <div className="h-px bg-slate-100 w-full"></div>
            <div className="relative pl-12">
              <span className="material-symbols-outlined absolute left-0 top-1 text-4xl text-amber-500">sentiment_neutral</span>
              <p className="text-sm font-bold text-slate-500 uppercase tracking-widest text-opacity-70">Yesterday | कल</p>
              <p className="text-3xl font-black text-slate-400">Fair Quality</p>
              <p className="text-slate-400 font-bold">साधारण पानी</p>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 rounded-3xl p-6 border border-blue-100">
          <p className="text-xs font-black text-blue-600 uppercase mb-4 tracking-widest">Guide | गाइड</p>
          <div className="space-y-3">
            {[
              { icon: 'sentiment_very_satisfied', color: 'text-emerald-500', text: 'Good to Drink | पीने योग्य' },
              { icon: 'sentiment_neutral', color: 'text-amber-500', text: 'Boil Before Drinking | उबाल कर पिएं' },
              { icon: 'sentiment_very_dissatisfied', color: 'text-red-500', text: 'Not Safe | पीने योग्य नहीं' },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <span className={`material-symbols-outlined ${item.color}`}>{item.icon}</span>
                <span className="text-sm font-bold">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Chart */}
      <div className="col-span-12 lg:col-span-8 bg-white rounded-3xl p-8 border border-slate-100 shadow-sm flex flex-col">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h4 className="text-xl font-black text-slate-900">7-Day Quality History</h4>
            <p className="text-slate-500 font-bold">पिछले 7 दिनों की पानी की गुणवत्ता</p>
          </div>
        </div>
        
        <div className="flex-1 min-h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={HISTORY}>
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={(props: any) => {
                  const item = HISTORY[props.index];
                  return (
                    <g transform={`translate(${props.x},${props.y + 20})`}>
                      <text x={0} y={0} textAnchor="middle" fill={props.index === 6 ? '#2D6A4F' : '#94a3b8'} fontWeight="bold" fontSize={12}>{item.day}</text>
                      <text x={0} y={15} textAnchor="middle" fill={props.index === 6 ? '#2D6A4F' : '#94a3b8'} fontSize={10}>{item.hindiDay}</text>
                    </g>
                  );
                }}
              />
              <Tooltip cursor={{ fill: '#f8fafc' }} content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="bg-white p-4 shadow-xl border border-slate-100 rounded-2xl">
                      <p className="font-bold">{payload[0].payload.day}</p>
                      <p className="text-2xl font-black">{payload[0].value}% Quality</p>
                    </div>
                  );
                }
                return null;
              }} />
              <Bar dataKey="quality" radius={[12, 12, 0, 0]} barSize={50}>
                {HISTORY.map((entry, index) => {
                  let color = '#d1fae5'; // good light
                  if (entry.status === 'medium') color = '#fef3c7';
                  if (entry.status === 'poor') color = '#fee2e2';
                  if (index === 6) color = '#2D6A4F'; // Current day
                  return <Cell key={`cell-${index}`} fill={color} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Safe to Drink CTA */}
      <div className="col-span-12 bg-white rounded-3xl p-8 border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-6">
          <div className="bg-amber-100 p-4 rounded-full text-amber-600">
            <span className="material-symbols-outlined text-4xl">lightbulb</span>
          </div>
          <div>
            <h5 className="text-lg font-black text-slate-900">Is it safe to drink? | क्या यह पानी पीने योग्य है?</h5>
            <p className="text-slate-500 font-medium">Today's water is clean. No need to boil. | आज का पानी साफ है। उबालने की जरूरत नहीं है।</p>
          </div>
        </div>
        <button className="w-full md:w-auto px-8 py-4 bg-primary text-white rounded-2xl font-black shadow-lg shadow-primary/25 hover:-translate-y-1 transition-all active:scale-95">
          Download Detailed Report | विस्तृत रिपोर्ट प्राप्त करें
        </button>
      </div>
    </div>
  );
};

export default WaterHistory;
