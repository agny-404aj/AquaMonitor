
import React from 'react';
import { WaterMetric, AIAnalysis } from '../types';
import MetricCard from '../components/MetricCard';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  metrics: WaterMetric[];
  analysis: AIAnalysis | null;
  isAnalyzing: boolean;
  onRefresh: () => void;
}

const data = [
  { time: '6 AM', quality: 65 },
  { time: '9 AM', quality: 78 },
  { time: '12 PM', quality: 82 },
  { time: '3 PM', quality: 75 },
  { time: '6 PM', quality: 88 },
  { time: '9 PM', quality: 90 },
];

const Dashboard: React.FC<DashboardProps> = ({ metrics, analysis, isAnalyzing }) => {
  const getBannerStyles = () => {
    if (isAnalyzing) return 'border-slate-300 bg-slate-50 text-slate-500';
    if (!analysis) return 'border-safe bg-safe/5 text-safe';
    
    switch (analysis.status) {
      case 'Danger': return 'border-danger-red bg-danger-red/5 text-danger-red';
      case 'Warning': return 'border-accent bg-accent/5 text-amber-700';
      default: return 'border-safe bg-safe/5 text-safe';
    }
  };

  const getStatusIcon = () => {
    if (isAnalyzing) return 'sync';
    if (!analysis) return 'check_circle';
    switch (analysis.status) {
      case 'Danger': return 'emergency';
      case 'Warning': return 'warning';
      default: return 'check_circle';
    }
  };

  return (
    <div className="flex flex-col gap-8">
      {/* System Status Banner */}
      <div className={`p-8 rounded-[2rem] border-4 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm transition-all duration-500 ${getBannerStyles()}`}>
        <div className="flex items-center gap-8">
          <div className={`rounded-full p-4 flex items-center justify-center shadow-lg transition-colors ${
            isAnalyzing ? 'bg-slate-400' : analysis?.status === 'Danger' ? 'bg-danger-red' : analysis?.status === 'Warning' ? 'bg-accent' : 'bg-safe'
          }`}>
            <span className={`material-symbols-outlined icon-large text-white ${isAnalyzing ? 'animate-spin' : ''}`}>{getStatusIcon()}</span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-baseline gap-3">
              <h2 className="text-3xl font-extrabold uppercase tracking-tighter">
                {isAnalyzing ? 'Analyzing...' : (analysis?.status || 'Safe')}
              </h2>
              <span className="text-4xl font-hindi font-bold">
                {isAnalyzing ? 'जाँच जारी...' : (analysis?.hindiStatus || 'सुरक्षित')}
              </span>
            </div>
            <p className="text-slate-600 font-medium text-lg mt-1">
              {isAnalyzing ? 'Fetching latest sensor data...' : (analysis ? `${analysis.verdict} / ${analysis.hindiVerdict}` : 'Water is clean and safe to drink.')}
            </p>
          </div>
        </div>
        {!isAnalyzing && analysis && (
          <div className="bg-white px-8 py-4 rounded-2xl border-2 border-inherit flex flex-col items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">AI Recommendation</span>
            <span className="text-xl font-hindi font-bold text-slate-800">{analysis.hindiRecommendation}</span>
          </div>
        )}
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {metrics.map((metric, idx) => (
          <MetricCard key={idx} metric={metric} />
        ))}
      </div>

      {/* Map and Tips Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 rounded-[2rem] border border-earth/10 bg-white overflow-hidden shadow-sm flex flex-col min-h-[450px]">
          <div className="p-6 border-b border-earth/5 flex justify-between items-center">
            <div className="flex flex-col">
              <h3 className="text-lg font-bold">Water Points Map</h3>
              <span className="text-xl font-hindi text-primary font-bold">जल स्रोतों का नक्शा</span>
            </div>
            <span className="px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase">Live Telemetry</span>
          </div>
          <div className="flex-1 bg-slate-100 relative">
            <div className="absolute inset-0 bg-cover bg-center opacity-80" style={{ backgroundImage: "url('https://picsum.photos/seed/map/800/400')" }}></div>
            <div className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
              <div className="bg-white p-2 rounded-xl shadow-2xl border-2 border-primary mb-2 flex items-center gap-2">
                <span className="material-symbols-outlined !text-xl text-primary">location_on</span>
                <span className="font-hindi font-bold">उत्तर कुआँ (North Well)</span>
              </div>
              <div className="size-6 bg-primary rounded-full border-4 border-white shadow-lg ring-4 ring-primary/20"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-earth text-white p-8 rounded-[2rem] flex flex-col justify-between shadow-xl">
          <div>
            <span className="material-symbols-outlined !text-5xl mb-4 text-accent">tips_and_updates</span>
            <h3 className="text-2xl font-bold mb-2">Health Tip</h3>
            <h4 className="text-3xl font-hindi font-bold mb-6 text-accent">स्वास्थ्य सलाह</h4>
            <div className="bg-white/10 p-6 rounded-2xl border border-white/10">
              <p className="text-lg leading-relaxed mb-4">Maintain 2m distance between waste disposal and water sources.</p>
              <p className="text-xl font-hindi font-bold text-accent">कूड़ेदान और पानी के स्रोत के बीच 2 मीटर की दूरी रखें।</p>
            </div>
          </div>
          <button className="w-full mt-8 py-4 bg-white text-earth rounded-2xl transition-all text-xl font-hindi font-bold shadow-lg">
            और जानें (Know More)
          </button>
        </div>
      </div>

      {/* Quality Trend Graph */}
      <div className="bg-white rounded-[2rem] border border-earth/5 p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex flex-col">
            <h3 className="text-xl font-bold">Water Quality Trend</h3>
            <span className="text-2xl font-hindi text-earth font-bold">गुणवत्ता का ग्राफ</span>
          </div>
          <div className="flex items-center gap-3 bg-background-village p-2 rounded-2xl">
            <button className="px-6 py-2 rounded-xl font-hindi text-lg font-bold bg-white shadow-sm text-primary">24 Hours</button>
            <button className="px-6 py-2 rounded-xl font-hindi text-lg font-bold text-slate-500">7 Days</button>
          </div>
        </div>
        <div className="w-full h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                labelStyle={{ fontWeight: 'bold' }}
              />
              <Line type="monotone" dataKey="quality" stroke="#2D6A4F" strokeWidth={4} dot={{ r: 6, fill: '#2D6A4F', strokeWidth: 3, stroke: '#fff' }} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
