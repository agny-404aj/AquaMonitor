
import React, { useState } from 'react';
import { WaterMetric } from '../types';

interface ManualEntryProps {
  onUpdate: (newMetrics: Partial<WaterMetric>[]) => void;
  metrics: WaterMetric[];
}

const ManualEntry: React.FC<ManualEntryProps> = ({ onUpdate, metrics }) => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Initialize with current values
  const [formData, setFormData] = useState({
    location: '',
    ph: metrics.find(m => m.id === 'ph')?.value.toString() || '7.0',
    turbidity: metrics.find(m => m.id === 'turbidity')?.value.toString() || '5.0',
    oxygen: metrics.find(m => m.id === 'oxygen')?.value.toString() || '8.0',
    temperature: metrics.find(m => m.id === 'temperature')?.value.toString() || '25.0',
    nitrate: metrics.find(m => m.id === 'nitrate')?.value.toString() || '10.0',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Pass updates back to parent state
    onUpdate([
      { id: 'ph', value: parseFloat(formData.ph) },
      { id: 'turbidity', value: parseFloat(formData.turbidity) },
      { id: 'oxygen', value: parseFloat(formData.oxygen) },
      { id: 'temperature', value: parseFloat(formData.temperature) },
      { id: 'nitrate', value: parseFloat(formData.nitrate) }
    ]);

    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="max-w-xl mx-auto flex flex-col items-center gap-8 py-10">
        <div className="bg-safe/10 border-2 border-safe/30 rounded-[2.5rem] p-12 flex flex-col items-center gap-8 text-center w-full shadow-2xl">
          <div className="bg-safe text-white rounded-full p-6 shadow-lg animate-bounce">
            <span className="material-symbols-outlined !text-6xl">verified</span>
          </div>
          <div>
            <h3 className="text-safe text-3xl font-extrabold uppercase tracking-tight">Data Submitted!</h3>
            <p className="text-safe/80 text-2xl font-bold mt-2">डेटा सफलतापूर्वक प्राप्त हुआ!</p>
            <p className="mt-4 text-slate-500 font-medium">Dashboard is being analyzed with new values...</p>
          </div>
          <button 
            onClick={() => setIsSubmitted(false)}
            className="w-full py-4 bg-safe text-white rounded-2xl font-bold text-xl hover:bg-safe/90 transition-all mt-4"
          >
            Make Another Entry / नई एंट्री
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto flex flex-col gap-8">
      <div className="text-center space-y-2 mb-4">
        <h1 className="text-slate-900 text-4xl font-black flex items-center justify-center gap-4">
          Sensor Override / <span className="text-primary">डेटा प्रविष्टि</span>
        </h1>
        <p className="text-slate-500 text-xl font-medium">Update manual measurements / मैन्युअल माप अपडेट करें</p>
      </div>

      <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100">
        <form className="flex flex-col gap-10" onSubmit={handleSubmit}>
          <div className="flex flex-col gap-4">
            <label className="flex items-center gap-3 text-slate-800 font-bold text-xl">
              <span className="material-symbols-outlined text-primary !text-4xl">location_on</span>
              Select Site / साइट चुनें
            </label>
            <select 
              required
              className="w-full rounded-2xl text-slate-900 border-2 border-slate-100 bg-slate-50 h-20 px-8 text-xl focus:ring-4 focus:ring-primary/20 focus:border-primary outline-none appearance-none transition-all shadow-sm"
              value={formData.location}
              onChange={(e) => setFormData({...formData, location: e.target.value})}
            >
              <option value="">Select location...</option>
              <option value="main-well">North Village Well / उत्तरी कुआँ</option>
              <option value="river-inlet">South Tank / दक्षिणी टंकी</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="flex flex-col gap-4">
              <label className="flex items-center gap-3 text-slate-800 font-bold text-xl text-blue-600">
                <span className="material-symbols-outlined !text-4xl">science</span>
                pH Level / पीएच
              </label>
              <input 
                required type="number" step="0.1" min="0" max="14"
                className="w-full rounded-2xl border-2 border-slate-100 bg-slate-50 h-24 px-8 text-3xl font-black focus:border-blue-500 outline-none transition-all"
                value={formData.ph}
                onChange={(e) => setFormData({...formData, ph: e.target.value})}
              />
            </div>

            <div className="flex flex-col gap-4">
              <label className="flex items-center gap-3 text-slate-800 font-bold text-xl text-amber-600">
                <span className="material-symbols-outlined !text-4xl">blur_on</span>
                Turbidity / गंदलापन
              </label>
              <input 
                required type="number" step="0.1"
                className="w-full rounded-2xl border-2 border-slate-100 bg-slate-50 h-24 px-8 text-3xl font-black focus:border-amber-500 outline-none transition-all"
                value={formData.turbidity}
                onChange={(e) => setFormData({...formData, turbidity: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="flex flex-col gap-4">
              <label className="flex items-center gap-3 text-slate-800 font-bold text-xl text-teal-600">
                <span className="material-symbols-outlined !text-4xl">bubble_chart</span>
                Dissolved Oxygen / ऑक्सीजन
              </label>
              <input 
                required type="number" step="0.1"
                className="w-full rounded-2xl border-2 border-slate-100 bg-slate-50 h-24 px-8 text-3xl font-black focus:border-teal-500 outline-none transition-all"
                value={formData.oxygen}
                onChange={(e) => setFormData({...formData, oxygen: e.target.value})}
              />
            </div>

            <div className="flex flex-col gap-4">
              <label className="flex items-center gap-3 text-slate-800 font-bold text-xl text-orange-600">
                <span className="material-symbols-outlined !text-4xl">thermostat</span>
                Temperature / तापमान (°C)
              </label>
              <input 
                required type="number" step="0.1"
                className="w-full rounded-2xl border-2 border-slate-100 bg-slate-50 h-24 px-8 text-3xl font-black focus:border-orange-500 outline-none transition-all"
                value={formData.temperature}
                onChange={(e) => setFormData({...formData, temperature: e.target.value})}
              />
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <label className="flex items-center gap-3 text-slate-800 font-bold text-xl text-purple-600">
              <span className="material-symbols-outlined !text-4xl">biotech</span>
              Nitrate / नाइट्रेट (mg/L)
            </label>
            <input 
              required type="number" step="0.1"
              className="w-full rounded-2xl border-2 border-slate-100 bg-slate-50 h-24 px-8 text-3xl font-black focus:border-purple-500 outline-none transition-all"
              value={formData.nitrate}
              onChange={(e) => setFormData({...formData, nitrate: e.target.value})}
            />
          </div>

          <button 
            type="submit"
            className="flex items-center justify-center gap-6 w-full rounded-3xl bg-primary text-white py-8 text-3xl font-black hover:bg-primary/90 active:scale-[0.98] transition-all shadow-2xl shadow-primary/20 uppercase tracking-wide mt-4"
          >
            Update Dashboard / अपडेट करें
          </button>
        </form>
      </div>

      <div className="flex items-start gap-6 p-8 bg-blue-50 rounded-3xl border border-blue-100 shadow-sm">
        <span className="material-symbols-outlined text-blue-500 !text-5xl">auto_awesome</span>
        <div>
          <p className="text-blue-800 font-black text-xl mb-1">AI Analysis / एआई विश्लेषण</p>
          <p className="text-blue-700/80 text-lg">Submitting these values will trigger a new AI assessment of the village water safety. / डेटा अपडेट करने पर एआई सुरक्षा की दोबारा जाँच करेगा।</p>
        </div>
      </div>
    </div>
  );
};

export default ManualEntry;
