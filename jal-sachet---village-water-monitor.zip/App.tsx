
import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Screen, WaterMetric, AIAnalysis } from './types';
import { INITIAL_METRICS } from './constants';
import Sidebar from './components/Sidebar';
import Dashboard from './screens/Dashboard';
import WaterHistory from './screens/WaterHistory';
import ManualEntry from './screens/ManualEntry';
import AlertsScreen from './screens/AlertsScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.HOME);
  const [metrics, setMetrics] = useState<WaterMetric[]>(INITIAL_METRICS);
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' };
    const dateStr = now.toLocaleDateString('hi-IN', options);
    setCurrentDate(`आज की तिथि: ${dateStr}`);
  }, []);

  const runAnalysis = useCallback(async (currentMetrics: WaterMetric[]) => {
    setIsAnalyzing(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `Analyze these water quality metrics for a village well:
    - pH: ${currentMetrics.find(m => m.id === 'ph')?.value}
    - Turbidity: ${currentMetrics.find(m => m.id === 'turbidity')?.value} NTU
    - Oxygen: ${currentMetrics.find(m => m.id === 'oxygen')?.value} mg/L
    - Temperature: ${currentMetrics.find(m => m.id === 'temperature')?.value} °C
    - Nitrate: ${currentMetrics.find(m => m.id === 'nitrate')?.value} mg/L
    
    Provide a safety verdict and recommendations in JSON format.
    Fields:
    - status: "Safe" | "Warning" | "Danger"
    - hindiStatus: Hindi translation of status
    - verdict: Brief technical assessment
    - hindiVerdict: Hindi assessment
    - recommendation: One action step
    - hindiRecommendation: Hindi action step`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: { type: Type.STRING },
              hindiStatus: { type: Type.STRING },
              verdict: { type: Type.STRING },
              hindiVerdict: { type: Type.STRING },
              recommendation: { type: Type.STRING },
              hindiRecommendation: { type: Type.STRING }
            },
            required: ['status', 'hindiStatus', 'verdict', 'hindiVerdict', 'recommendation', 'hindiRecommendation']
          }
        }
      });
      
      const result = JSON.parse(response.text);
      setAnalysis(result);
    } catch (error) {
      console.error("AI Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  // Run initial analysis
  useEffect(() => {
    runAnalysis(metrics);
  }, []);

  const handleUpdateMetrics = (newMetrics: Partial<WaterMetric>[]) => {
    const updated = metrics.map(m => {
      const update = newMetrics.find(u => u.id === m.id);
      if (update) {
        // Calculate dynamic percentages based on rough limits
        let maxVal = 10;
        if (m.id === 'ph') maxVal = 14;
        if (m.id === 'temperature') maxVal = 50;
        if (m.id === 'nitrate') maxVal = 50;
        
        return { 
          ...m, 
          ...update, 
          percentage: update.value !== undefined ? (update.value / maxVal) * 100 : m.percentage 
        };
      }
      return m;
    });
    setMetrics(updated);
    runAnalysis(updated);
  };

  const simulateSensors = () => {
    const simulated = metrics.map(m => {
      let newVal = m.value;
      let maxVal = 10;
      if (m.id === 'ph') {
        newVal = Number((6.5 + Math.random() * 2).toFixed(1));
        maxVal = 14;
      } else if (m.id === 'turbidity') {
        newVal = Number((Math.random() * 10).toFixed(1));
        maxVal = 10;
      } else if (m.id === 'oxygen') {
        newVal = Number((5 + Math.random() * 5).toFixed(1));
        maxVal = 10;
      } else if (m.id === 'temperature') {
        newVal = Number((20 + Math.random() * 10).toFixed(1));
        maxVal = 50;
      } else if (m.id === 'nitrate') {
        newVal = Number((5 + Math.random() * 20).toFixed(1));
        maxVal = 50;
      }
      return { ...m, value: newVal, percentage: (newVal / maxVal) * 100 };
    });
    setMetrics(simulated);
    runAnalysis(simulated);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.HOME:
        return <Dashboard metrics={metrics} analysis={analysis} isAnalyzing={isAnalyzing} onRefresh={simulateSensors} />;
      case Screen.HISTORY:
        return <WaterHistory />;
      case Screen.MANUAL_ENTRY:
        return <ManualEntry onUpdate={handleUpdateMetrics} metrics={metrics} />;
      case Screen.ALERTS:
        return <AlertsScreen />;
      default:
        return <Dashboard metrics={metrics} analysis={analysis} isAnalyzing={isAnalyzing} onRefresh={simulateSensors} />;
    }
  };

  const getScreenTitles = () => {
    switch (currentScreen) {
      case Screen.HOME: return { en: 'Village Dashboard', hi: 'गाँव जल निगरानी डैशबोर्ड' };
      case Screen.HISTORY: return { en: 'Water History', hi: 'पानी की गुणवत्ता का इतिहास' };
      case Screen.MANUAL_ENTRY: return { en: 'Manual Entry', hi: 'मैनुअल डेटा प्रविष्टि' };
      case Screen.ALERTS: return { en: 'Community Alerts', hi: 'सामुदायिक सूचनाएं' };
    }
  };

  const titles = getScreenTitles();

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar currentScreen={currentScreen} onNavigate={setCurrentScreen} />
      
      <main className="flex-1 flex flex-col overflow-y-auto">
        <header className="h-20 bg-white/80 backdrop-blur-md px-10 flex items-center justify-between border-b border-earth/10 sticky top-0 z-20">
          <div className="flex flex-col">
            <h2 className="text-sm font-bold text-earth/60 uppercase tracking-widest">{titles.en}</h2>
            <h3 className="text-2xl font-bold font-hindi text-primary">{titles.hi}</h3>
          </div>
          <div className="flex items-center gap-8">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-500">System Status</p>
              <p className="text-lg font-hindi font-bold text-primary">प्रणाली सक्रिय है</p>
            </div>
            <button 
              onClick={simulateSensors}
              className="bg-primary/5 text-primary border-2 border-primary/20 font-bold px-6 py-2.5 rounded-xl hover:bg-primary/10 transition-all flex items-center gap-2"
            >
              <span className={`material-symbols-outlined !text-xl ${isAnalyzing ? 'animate-spin' : ''}`}>sync</span>
              <span className="font-hindi text-lg">सेंसर रिफ्रेश</span>
            </button>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto w-full">
          {renderScreen()}
        </div>
        
        <footer className="py-12 px-10 text-center border-t border-slate-200 bg-white mt-auto">
          <p className="text-slate-500 text-sm font-medium">AquaMonitor Rural Portal • Village Water Safety Initiative</p>
          <p className="text-slate-400 text-xs mt-1">AI Enabled Analysis Powered by Gemini • ग्राम पंचायत जल सुरक्षा प्रणाली</p>
        </footer>
      </main>
    </div>
  );
};

export default App;
