
export enum Screen {
  HOME = 'home',
  HISTORY = 'history',
  MANUAL_ENTRY = 'manual_entry',
  ALERTS = 'alerts'
}

export interface WaterMetric {
  id: string;
  label: string;
  hindiLabel: string;
  value: number;
  unit: string;
  status: string;
  hindiStatus: string;
  icon: string;
  color: string;
  percentage: number;
}

export interface AIAnalysis {
  status: 'Safe' | 'Warning' | 'Danger';
  hindiStatus: string;
  verdict: string;
  hindiVerdict: string;
  recommendation: string;
  hindiRecommendation: string;
}

export interface Alert {
  id: string;
  title: string;
  hindiTitle: string;
  description: string;
  hindiDescription: string;
  time: string;
  type: 'info' | 'warning' | 'danger';
}

export interface HistoryItem {
  day: string;
  hindiDay: string;
  quality: number;
  status: 'good' | 'medium' | 'poor';
}
