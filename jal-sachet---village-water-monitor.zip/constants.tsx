
import { WaterMetric, Alert, HistoryItem } from './types';

export const INITIAL_METRICS: WaterMetric[] = [
  {
    id: 'ph',
    label: 'pH Level',
    hindiLabel: 'पीएच स्तर',
    value: 7.2,
    unit: 'pH',
    status: 'Balanced',
    hindiStatus: 'संतुलित',
    icon: 'water_drop',
    color: 'blue',
    percentage: 72
  },
  {
    id: 'turbidity',
    label: 'Turbidity',
    hindiLabel: 'गंदलापन',
    value: 4.5,
    unit: 'NTU',
    status: 'Clear Water',
    hindiStatus: 'साफ पानी',
    icon: 'filter_drama',
    color: 'amber',
    percentage: 45
  },
  {
    id: 'oxygen',
    label: 'Oxygen',
    hindiLabel: 'ऑक्सीजन',
    value: 8.2,
    unit: 'mg/L',
    status: 'Excellent',
    hindiStatus: 'उत्तम',
    icon: 'bubble_chart',
    color: 'teal',
    percentage: 82
  },
  {
    id: 'temperature',
    label: 'Temperature',
    hindiLabel: 'तापमान',
    value: 24.5,
    unit: '°C',
    status: 'Normal',
    hindiStatus: 'सामान्य',
    icon: 'thermostat',
    color: 'orange',
    percentage: 49
  },
  {
    id: 'nitrate',
    label: 'Nitrate',
    hindiLabel: 'नाइट्रेट',
    value: 12.0,
    unit: 'mg/L',
    status: 'Safe',
    hindiStatus: 'सुरक्षित',
    icon: 'biotech',
    color: 'purple',
    percentage: 30
  }
];

export const ALERTS: Alert[] = [
  {
    id: '1',
    title: 'Tank Cleaning Schedule',
    hindiTitle: 'टंकी की सफाई',
    description: 'Main overhead tank will be cleaned this Sunday. No water supply between 8 AM and 12 PM.',
    hindiDescription: 'रविवार को मुख्य टंकी की सफाई की जाएगी। सुबह 8 से दोपहर 12 बजे तक पानी की आपूर्ति बंद रहेगी।',
    time: '2 Hours Ago',
    type: 'info'
  }
];

export const HISTORY: HistoryItem[] = [
  { day: 'MON', hindiDay: 'सोम', quality: 85, status: 'good' },
  { day: 'TUE', hindiDay: 'मंगल', quality: 92, status: 'good' },
  { day: 'WED', hindiDay: 'बुध', quality: 35, status: 'poor' },
  { day: 'THU', hindiDay: 'गुरु', quality: 60, status: 'medium' },
  { day: 'FRI', hindiDay: 'शुक्र', quality: 80, status: 'good' },
  { day: 'SAT', hindiDay: 'शनि', quality: 65, status: 'medium' },
  { day: 'SUN', hindiDay: 'रवि', quality: 95, status: 'good' },
];
